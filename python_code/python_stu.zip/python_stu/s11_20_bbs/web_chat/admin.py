from django.contrib import admin

# Register your models here.
from web_chat import models

admin.site.register(models.ChatGroup)
