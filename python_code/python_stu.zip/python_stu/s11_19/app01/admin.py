from django.contrib import admin

# Register your models here.
import models

admin.site.register(models.UserInfo)
admin.site.register(models.SimpleModel)
