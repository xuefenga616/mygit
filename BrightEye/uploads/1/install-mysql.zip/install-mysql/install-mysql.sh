#/bin/sh

echo "install-mysql scripts!"