#/bin/sh

echo "start-mysql scripts!"
yum -y install glibc