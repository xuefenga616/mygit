#/bin/sh

echo "start-mysql scripts!"